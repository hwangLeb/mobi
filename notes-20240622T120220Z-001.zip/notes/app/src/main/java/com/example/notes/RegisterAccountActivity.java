package com.example.notes;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Firebase;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterAccountActivity extends AppCompatActivity {

    EditText nameEditText, emailaddressEditText, passwordEditText, comfirmPasswordEditText;
    Button createAccountBtn;
    ProgressBar progressBar;
    TextView loginBtnTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register_account);

        nameEditText = findViewById(R.id.Name_edit_text);
        emailaddressEditText = findViewById(R.id.Email_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);
        comfirmPasswordEditText = findViewById(R.id.confirm_password_edit_text);
        createAccountBtn = findViewById(R.id.create_account_btn);
        progressBar = findViewById(R.id.progress_bar);
        loginBtnTextView = findViewById(R.id.Signin_btn);

        createAccountBtn.setOnClickListener(v -> createAccount());
        loginBtnTextView.setOnClickListener(v -> finish());
    }

    void createAccount(){
        String name = nameEditText.getText().toString();
        String email = emailaddressEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        String confirmPassword = comfirmPasswordEditText.getText().toString();

        boolean isValidated = validateData(name,email,password,confirmPassword);
        if(!isValidated){
            return;
        }

        createAccountInFirebase(email,password);
    }

    void createAccountInFirebase(String email, String password){
        changeInProgress(true);

        FirebaseAuth FirebaseAuth = com.google.firebase.auth.FirebaseAuth.getInstance();
        FirebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(RegisterAccountActivity.this,
                new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        changeInProgress(false);
                        if (task.isSuccessful()){
                            Utility.showToast(RegisterAccountActivity.this,"Congratulations, Your Account Has Been Successfully Created!");
                            FirebaseAuth.getCurrentUser().sendEmailVerification();
                            FirebaseAuth.signOut();

                        }else{
                            ///fail
                            Utility.showToast(RegisterAccountActivity.this,task.getException().getLocalizedMessage());
                        }
                    }
                }
        );

    }

    void changeInProgress(boolean inProgress){
        if(inProgress){
            progressBar.setVisibility(View.VISIBLE);
            createAccountBtn.setVisibility(View.GONE);
        } else{
            progressBar.setVisibility(View.GONE);
            createAccountBtn.setVisibility(View.VISIBLE);
        }
    }


    boolean validateData(String name, String email,String password,String confirmPassword){


        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            emailaddressEditText.setError("Email Address is Invalid!");
            return false;
        }

        if (password.length()<7){
            passwordEditText.setError("Password length is Invalid!");
            return false;
        }

        if (!password.equals(confirmPassword)){
            comfirmPasswordEditText.setError("Password not matched!");
            return false;
        }
        return true;
    }
}