package com.example.notes;

import static java.sql.Timestamp.*;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;

import java.sql.Timestamp;

public class NoteActivity extends AppCompatActivity {

    EditText TitleEditText,contentEditText;
    ImageButton saveNoteBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_note);

        TitleEditText = findViewById(R.id.Title_note);
        contentEditText = findViewById(R.id.Content_note);
        saveNoteBtn = findViewById(R.id.save_btn);

        saveNoteBtn.setOnClickListener(v -> saveNote());

    }

    void saveNote(){
        String NoteTitle = TitleEditText.getText().toString();
        String NoteContent = contentEditText.getText().toString();
        if(NoteTitle==null || NoteTitle.isEmpty()){
            TitleEditText.setError("Title is Required!");
            return;
        }

        Note note =  new Note();
        note.setTitle(NoteTitle);
        note.setContent(NoteContent);

        saveNoteToFirebase(note);

    }
    void saveNoteToFirebase(Note note){
        DocumentReference documentReference;
        documentReference = Utility.getCollectionReferenceForNotes().document();

        documentReference.set(note).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Utility.showToast(NoteActivity.this, "Note Added Successfully!");
                    finish();
                }else{
                    Utility.showToast(NoteActivity.this, "Note Added Unsuccessfully!");
                }
            }
        });
    }
}